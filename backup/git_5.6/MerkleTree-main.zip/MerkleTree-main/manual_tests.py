
    
    
# This function get a tree (Node type) and return its rightest leaf.                # REMOVE ?
# def find_newest_leaf(tree):
#     if (tree.right is not None):
#         return find_newest_leaf(tree.right)
#     elif (tree.left is not None):
#         return find_newest_leaf(tree.left)
#     else:
#         return tree